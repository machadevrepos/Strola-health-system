import { Crown, SealCheck } from "@phosphor-icons/react";
import { Badge } from "@/components/ui/badge";
import { ROLE_LABEL } from "@/lib/format";
import type { Role, UserProfile } from "@/lib/types";

// Every chip in the app uses the same light/tinted treatment: a soft
// percentage-opacity fill of the semantic color with the color itself (or a
// darker "strong" variant for amber, which is too light to read as text on
// its own tint) as the text. No solid/saturated chip fills — that reads as
// heavy on a dense admin screen full of them.

export function RoleBadge({ role }: { role: Role }) {
  if (role === "super_admin") return <Badge className="bg-primary/12 text-primary">{ROLE_LABEL[role]}</Badge>;
  if (role === "admin") return <Badge className="bg-secondary text-foreground">{ROLE_LABEL[role]}</Badge>;
  return <Badge variant="outline">{ROLE_LABEL[role]}</Badge>;
}

// Inline icon (not a pill) next to a comment/post author's name in the
// community — mirrors the mobile app's treatment (see
// PublicProfile.communityDisplayName in strola_health_flutter). Super admin
// gets the brand-gold crown for a "more legendary" presence than a regular
// admin's checkmark, same amber token the Premium/Trial badges already use.
export function CommunityAuthorBadge({ role }: { role: Role | undefined }) {
  if (role === "super_admin") return <Crown size={13} weight="fill" className="text-brand-accent-strong" aria-label="Super admin" />;
  if (role === "admin") return <SealCheck size={13} weight="fill" className="text-primary" aria-label="Admin" />;
  return null;
}

export function SubscriptionBadge({ subscription }: { subscription: UserProfile["subscription"] }) {
  // Tier badges deliberately use a different color axis than account-status
  // badges (success green / destructive red): Premium is a commercial tier,
  // not a health signal, so it carries the brand color instead of reusing
  // "green = good" — keeps it visually distinct from an adjacent Active pill.
  const { tier, status, comp_until, comp_reason } = subscription;
  // Comp access is an independent grant, not layered on top of tier/status
  // (see `classifySubscription` in lib/data/queries.ts) — checked first so
  // a comp'd user still reads as "Premium" even though comp deliberately
  // never overwrites their underlying tier/status.
  const hasComp = !!comp_until && new Date(comp_until) > new Date() && comp_reason !== "signup_trial";
  if (hasComp || (tier === "premium" && status === "active")) {
    return <Badge className="bg-primary/12 text-primary">Premium</Badge>;
  }
  if (status === "trialing") {
    return <Badge className="bg-brand-accent/20 text-brand-accent-strong">Trial</Badge>;
  }
  if (status === "cancelled") {
    return <Badge variant="outline">Cancelling</Badge>;
  }
  return <Badge variant="secondary">Free</Badge>;
}

export function AccountStatusBadge({ user }: { user: UserProfile }) {
  if (user.deleted) return <Badge variant="outline">Deleted</Badge>;
  if (user.banned) return <Badge className="bg-destructive/12 text-destructive">Suspended</Badge>;
  return <Badge className="bg-success/15 text-success">Active</Badge>;
}

export function ReportStatusBadge({ status }: { status: "open" | "resolved" | "dismissed" }) {
  if (status === "open") return <Badge className="bg-destructive/12 text-destructive">Open</Badge>;
  if (status === "resolved") return <Badge className="bg-success/15 text-success">Resolved</Badge>;
  return <Badge variant="secondary">Dismissed</Badge>;
}

export function ChallengeStatusBadge({ status }: { status: "upcoming" | "active" | "ended" }) {
  if (status === "active") return <Badge className="bg-success/15 text-success">Active</Badge>;
  if (status === "upcoming") return <Badge className="bg-brand-accent/20 text-brand-accent-strong">Upcoming</Badge>;
  return <Badge variant="secondary">Ended</Badge>;
}
