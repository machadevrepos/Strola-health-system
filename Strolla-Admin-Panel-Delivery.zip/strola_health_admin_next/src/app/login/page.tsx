"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { signInWithEmailAndPassword } from "firebase/auth";
import { CircleNotch, Eye, EyeSlash } from "@phosphor-icons/react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { InputGroup, InputGroupAddon, InputGroupButton, InputGroupInput } from "@/components/ui/input-group";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { getFirebaseAuth } from "@/lib/firebase-client";
import { IS_MOCK_MODE } from "@/lib/mock-mode";
import { useAuth } from "@/lib/auth-context";

export default function LoginPage() {
  const router = useRouter();
  const { mockSignIn } = useAuth();
  const [email, setEmail] = React.useState("");
  const [password, setPassword] = React.useState("");
  const [showPassword, setShowPassword] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [submitting, setSubmitting] = React.useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      if (IS_MOCK_MODE) {
        mockSignIn(email);
        router.push("/");
        return;
      }
      await signInWithEmailAndPassword(getFirebaseAuth(), email.trim(), password);
      router.push("/");
    } catch {
      setError("Incorrect email or password.");
    } finally {
      setSubmitting(false);
    }
  }

  function continueAsDemo() {
    mockSignIn(email || "demo@strollahealth.com");
    router.push("/");
  }

  return (
    <div className="flex min-h-dvh items-center justify-center bg-secondary px-4">
      <Card className="w-full max-w-sm border-border shadow-none">
        <CardHeader>
          <div className="mb-1 flex size-8 items-center justify-center rounded-md bg-primary text-sm font-semibold text-primary-foreground">
            S
          </div>
          <CardTitle>Sign in to Strolla Admin</CardTitle>
          <CardDescription>
            {IS_MOCK_MODE ? "Demo build — any email and password works." : "Staff access only."}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={onSubmit} className="space-y-4">
            <div className="grid gap-2">
              <Label htmlFor="login-email">Email</Label>
              <Input
                id="login-email"
                type="email"
                autoComplete="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder={IS_MOCK_MODE ? "support.maya@strollahealth.com" : undefined}
                required={!IS_MOCK_MODE}
                autoFocus
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="login-password">Password</Label>
              <InputGroup>
                <InputGroupInput
                  id="login-password"
                  type={showPassword ? "text" : "password"}
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required={!IS_MOCK_MODE}
                />
                <InputGroupAddon align="inline-end">
                  <InputGroupButton
                    type="button"
                    size="icon-xs"
                    aria-label={showPassword ? "Hide password" : "Show password"}
                    onClick={() => setShowPassword((v) => !v)}
                  >
                    {showPassword ? <EyeSlash size={14} /> : <Eye size={14} />}
                  </InputGroupButton>
                </InputGroupAddon>
              </InputGroup>
            </div>
            {error && <p className="text-sm text-destructive">{error}</p>}
            <Button type="submit" className="w-full" disabled={submitting}>
              {submitting && <CircleNotch size={14} className="animate-spin" />}
              Sign in
            </Button>
            {IS_MOCK_MODE && (
              <Button type="button" variant="outline" className="w-full" onClick={continueAsDemo}>
                Skip — continue as demo staff
              </Button>
            )}
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
