"use client";

import { PageHeader } from "@/components/shell/page-header";
import { PageError, PageLoading } from "@/components/shell/page-states";
import { ModerationView } from "@/components/moderation/moderation-view";
import { fetchPosts, fetchReports, fetchUsers } from "@/lib/data/api";
import { enrichPosts, enrichReports } from "@/lib/data/queries";
import { useApiData } from "@/lib/use-api-data";

async function loadModeration() {
  const [users, rawPosts, rawReports] = await Promise.all([fetchUsers(), fetchPosts(true), fetchReports()]);
  return {
    posts: enrichPosts(rawPosts, users),
    reports: enrichReports(rawReports, users, rawPosts),
  };
}

export default function ModerationPage() {
  const { data, loading, error, reload } = useApiData(loadModeration);

  return (
    <div>
      <PageHeader title="Moderation" description="Resolve user reports on posts and accounts." />
      {loading && <PageLoading />}
      {error && <PageError message={error} onRetry={reload} />}
      {data && <ModerationView posts={data.posts} reports={data.reports} />}
    </div>
  );
}
